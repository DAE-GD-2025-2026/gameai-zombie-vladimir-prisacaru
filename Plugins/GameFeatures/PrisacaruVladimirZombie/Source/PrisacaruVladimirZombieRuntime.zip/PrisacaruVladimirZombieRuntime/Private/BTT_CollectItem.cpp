// Fill out your copyright notice in the Description page of Project Settings.

#include "BTT_CollectItem.h"
#include "StudentPerceptor.h"
#include "AIController.h"
#include "Navigation/PathFollowingComponent.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Common/HealthComponent.h"
#include "Common/InventoryComponent.h"
#include "Items/BaseItem.h"
#include "Items/ItemType.h"
#include "Village/House/House.h"
#include "Survivor/SurvivorPawn.h"

UBTT_CollectItem::UBTT_CollectItem()
{
	NodeName    = TEXT("Collect Item");
	bNotifyTick = true;
}

EBTNodeResult::Type UBTT_CollectItem::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* Controller = OwnerComp.GetAIOwner();
	if (!Controller) return EBTNodeResult::Failed;

	APawn* Pawn = Controller->GetPawn();
	if (!Pawn)       return EBTNodeResult::Failed;

	ABaseItem* Best = PickBestItem(Pawn);
	if (!Best) return EBTNodeResult::Failed;

	// Don't bother moving if inventory is already full
	ASurvivorPawn* Survivor = Cast<ASurvivorPawn>(Pawn);
	UInventoryComponent* Inv = Survivor ? Survivor->GetComponentByClass<UInventoryComponent>() : nullptr;
	if (Inv)
	{
		const bool bFull = !Inv->GetInventory().ContainsByPredicate(
			[](const ABaseItem* Item){ return Item == nullptr; });
		if (bFull) return EBTNodeResult::Failed;
	}

	// Write to blackboard so decorators/other tasks can read it
	if (UStudentPerceptor* P = Pawn->GetComponentByClass<UStudentPerceptor>())
	{
		if (UBlackboardComponent* BB = P->GetBlackboard())
			BB->SetValueAsObject(BBKeys::TargetItem, Best);
	}

	FCollectItemMemory* Mem = reinterpret_cast<FCollectItemMemory*>(NodeMemory);
	Mem->TargetItem   = Best;
	Mem->TimeElapsed  = 0.f;

	FAIMoveRequest MoveReq(Best->GetActorLocation());
	MoveReq.SetUsePathfinding(true);
	MoveReq.SetAcceptanceRadius(10.f);
	Controller->MoveTo(MoveReq);

	return EBTNodeResult::InProgress;
}

void UBTT_CollectItem::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickTask(OwnerComp, NodeMemory, DeltaSeconds);

	AAIController* Controller = OwnerComp.GetAIOwner();
	if (!Controller) { FinishLatentTask(OwnerComp, EBTNodeResult::Failed); return; }

	APawn* Pawn = Controller->GetPawn();
	if (!Pawn)       { FinishLatentTask(OwnerComp, EBTNodeResult::Failed); return; }

	FCollectItemMemory* Mem = reinterpret_cast<FCollectItemMemory*>(NodeMemory);

	if (!Mem->TargetItem.IsValid())
	{
		// Item disappeared (already picked up by someone else)
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
		return;
	}

	// ---- Timeout ----
	Mem->TimeElapsed += DeltaSeconds;
	if (MoveTimeout > 0.f && Mem->TimeElapsed >= MoveTimeout)
	{
		Controller->StopMovement();
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
		return;
	}

	// ---- Pickup check ----
	ASurvivorPawn* Survivor = Cast<ASurvivorPawn>(Pawn);
	if (!Survivor) return;

	UInventoryComponent* Inv = Survivor->GetComponentByClass<UInventoryComponent>();
	if (!Inv) return;

	// Find a free inventory slot up front — if none, fail rather than loop forever
	int32 FreeSlot = INDEX_NONE;
	for (int32 i = 0; i < Inv->GetInventoryCapacity(); ++i)
	{
		if (Inv->GetInventory().IsValidIndex(i) && Inv->GetInventory()[i] == nullptr)
		{
			FreeSlot = i;
			break;
		}
	}

	if (FreeSlot == INDEX_NONE)
	{
		// Inventory full — nothing we can do, fail gracefully
		Controller->StopMovement();
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
		return;
	}

	const float DistToItem = FVector::Dist(Pawn->GetActorLocation(),
	                                        Mem->TargetItem->GetActorLocation());

	// Trigger pickup on arrival OR when the path-follower goes idle
	// (controller reached acceptance radius before this tick ran)
	const UPathFollowingComponent* PFC = Controller->GetPathFollowingComponent();
	const bool bPathDone = PFC && PFC->GetStatus() == EPathFollowingStatus::Idle;

	if (DistToItem <= Inv->GetPickupRange() || bPathDone)
	{
		if (DistToItem <= Inv->GetPickupRange())
		{
			Inv->GrabItem(FreeSlot, Mem->TargetItem.Get());
		}

		Controller->StopMovement();
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
	}
}

EBTNodeResult::Type UBTT_CollectItem::AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	if (AAIController* Controller = OwnerComp.GetAIOwner())
		Controller->StopMovement();
	return Super::AbortTask(OwnerComp, NodeMemory);
}

uint16 UBTT_CollectItem::GetInstanceMemorySize() const { return sizeof(FCollectItemMemory); }

// ---------------------------------------------------------------------------

ABaseItem* UBTT_CollectItem::PickBestItem(APawn* Pawn) const
{
	UStudentPerceptor* Perceptor = Pawn->GetComponentByClass<UStudentPerceptor>();
	if (!Perceptor) return nullptr;

	ASurvivorPawn* Survivor = Cast<ASurvivorPawn>(Pawn);
	UHealthComponent* Health = Survivor
		? Survivor->GetComponentByClass<UHealthComponent>()
		: nullptr;

	const float HPFraction = (Health && Health->GetMaxHealth() > 0)
		? static_cast<float>(Health->GetHealth()) / Health->GetMaxHealth()
		: 1.f;

	const bool bLowHealth = HPFraction < LowHealthThreshold;

	// Score items: lower = better (we pick the minimum)
	auto ScoreItem = [&](const ABaseItem* Item) -> int32
	{
		switch (Item->GetItemType())
		{
			case EItemType::Medkit:  return bLowHealth  ? 0 : 5;
			case EItemType::Food:    return bLowHealth  ? 1 : 4;
			case EItemType::Shotgun: return !bLowHealth ? 0 : 6;
			case EItemType::Pistol:  return !bLowHealth ? 1 : 6;
			default:                 return 99;
		}
	};

	const FVector PawnPos = Pawn->GetActorLocation();

	// Find nearest house for distance comparison
	float NearestHouseDist = MAX_FLT;
	for (AHouse* House : Perceptor->GetSeenHouses())
	{
		if (!IsValid(House)) continue;
		const float D = FVector::Dist(PawnPos, House->GetActorLocation());
		if (D < NearestHouseDist) NearestHouseDist = D;
	}

	ABaseItem* Best      = nullptr;
	int32      BestScore = MAX_int32;

	for (ABaseItem* Item : Perceptor->GetSeenItems())
	{
		if (!IsValid(Item)) continue;

		const float ItemDist = FVector::Dist(PawnPos, Item->GetActorLocation());

		// If item is farther than the nearest unsearched house, skip it —
		// caller should go to the house first to find closer items.
		if (ItemDist > NearestHouseDist) continue;

		const int32 Score = ScoreItem(Item);
		if (Score < BestScore)
		{
			BestScore = Score;
			Best      = Item;
		}
	}

	return Best;
}