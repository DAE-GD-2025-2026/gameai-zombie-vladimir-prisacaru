﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "StudentPerceptor.h"
#include "AIController.h"

UStudentPerceptor::UStudentPerceptor()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UStudentPerceptor::BeginPlay()
{
	Super::BeginPlay();

	if (auto* PerceptionComp = GetOwner()->GetComponentByClass<UAIPerceptionComponent>())
	{
		PerceptionComp->OnTargetPerceptionUpdated.AddDynamic(this, &UStudentPerceptor::OnPerceptionUpdated);
	}

	// Cache blackboard once at begin play
	if (APawn* Pawn = Cast<APawn>(GetOwner()))
	{
		if (AAIController* AI = Cast<AAIController>(Pawn->GetController()))
		{
			BB = AI->GetBlackboardComponent();
		}
	}
}

void UStudentPerceptor::OnPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus)
{
	// ---- Items ----
	if (ABaseItem* Item = Cast<ABaseItem>(Actor);
		Item && !SeenItems.Contains(Item))
	{
		SeenItems.Add(Item);
		UpdateBlackboardActionableFlag();
		GEngine->AddOnScreenDebugMessage(5, 1.f, FColor::Green, TEXT("Saw item!"));
	}

	// ---- Houses ----
	if (AHouse* House = Cast<AHouse>(Actor);
		House && !SeenHouses.Contains(House))
	{
		SeenHouses.Add(House);
		UpdateBlackboardActionableFlag();
		GEngine->AddOnScreenDebugMessage(5, 1.f, FColor::Green, TEXT("Saw house!"));
	}

	// ---- Zombies ----
	if (ABaseZombie* Zombie = Cast<ABaseZombie>(Actor);
		Zombie && !SeenZombies.Contains(Zombie))
	{
		SeenZombies.Add(Zombie);
		UpdateBlackboardZombieFlag();
		GEngine->AddOnScreenDebugMessage(5, 1.f, FColor::Red, TEXT("Saw zombie!"));
	}

	// ---- Purge zones ----
	if (APurgeZone* Purge = Cast<APurgeZone>(Actor);
		Purge && !SeenPurgeZones.Contains(Purge))
	{
		SeenPurgeZones.Add(Purge);
		UpdateBlackboardPurgeFlag();
		GEngine->AddOnScreenDebugMessage(5, 1.f, FColor::Orange, TEXT("Saw purge zone!"));
	}

	// ---- Damage stimulus: trigger 360 spin to find unseen attackers ----
	if (Stimulus.Type == UAISense::GetSenseID<UAISense_Damage>())
	{
		if (BB)
		{
			BB->SetValueAsBool(BBKeys::ShouldSpin, true);
		}
	}
}

// ---------------------------------------------------------------------------

void UStudentPerceptor::MarkCurrentPositionExplored()
{
	if (!GetOwner()) return;

	const FVector CurrentPos = GetOwner()->GetActorLocation();

	for (const FVector& Existing : ExploredPositions)
	{
		if (FVector::DistSquared(CurrentPos, Existing) < MinRecordDistance * MinRecordDistance)
			return;
	}

	ExploredPositions.Add(CurrentPos);
}

int32 UStudentPerceptor::GetExplorationDensity(const FVector& WorldPos, float Radius) const
{
	const float RadiusSq = Radius * Radius;
	int32 Count = 0;

	for (const FVector& Pos : ExploredPositions)
	{
		if (FVector::DistSquared(WorldPos, Pos) <= RadiusSq)
			++Count;
	}

	return Count;
}

// ---------------------------------------------------------------------------

void UStudentPerceptor::UpdateBlackboardZombieFlag()
{
	if (!BB) return;

	const bool bSees = SeenZombies.Num() > 0;
	BB->SetValueAsBool(BBKeys::SeesZombies, bSees);

	GEngine->AddOnScreenDebugMessage(6, 1.f, FColor::Red,
		FString::Printf(TEXT("bSeesZombies: %s"), bSees ? TEXT("true") : TEXT("false")));

	if (bSees)
	{
		// FleeFromLocation = average zombie position
		// (purge zone takes priority when both are active; purge update overwrites)
		FVector Avg = FVector::ZeroVector;
		for (const ABaseZombie* Z : SeenZombies)
		{
			if (IsValid(Z)) Avg += Z->GetActorLocation();
		}
		Avg /= SeenZombies.Num();
		BB->SetValueAsVector(BBKeys::FleeFromLocation, Avg);
	}
}

void UStudentPerceptor::UpdateBlackboardActionableFlag()
{
	if (!BB) return;
	const bool bHas = SeenItems.Num() > 0 || SeenHouses.Num() > 0;
	BB->SetValueAsBool(BBKeys::HasActionableItem, bHas);
}

void UStudentPerceptor::UpdateBlackboardPurgeFlag()
{
	if (!BB) return;

	const bool bSees = SeenPurgeZones.Num() > 0;
	BB->SetValueAsBool(BBKeys::SeesPurgeZone, bSees);

	GEngine->AddOnScreenDebugMessage(7, 1.f, FColor::Orange,
		FString::Printf(TEXT("bSeesPurgeZone: %s"), bSees ? TEXT("true") : TEXT("false")));

	if (bSees)
	{
		// Use the nearest purge zone as the flee-from point
		// Purge zone center IS the actor location
		const FVector PawnPos = GetOwner() ? GetOwner()->GetActorLocation() : FVector::ZeroVector;
		APurgeZone* Nearest = nullptr;
		float NearestDistSq = MAX_FLT;

		for (APurgeZone* P : SeenPurgeZones)
		{
			if (!IsValid(P)) continue;
			const float D = FVector::DistSquared(PawnPos, P->GetActorLocation());
			if (D < NearestDistSq)
			{
				NearestDistSq = D;
				Nearest = P;
			}
		}

		if (Nearest)
		{
			BB->SetValueAsVector(BBKeys::FleeFromLocation, Nearest->GetActorLocation());
		}
	}
}