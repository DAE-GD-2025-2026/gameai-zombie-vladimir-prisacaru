// Fill out your copyright notice in the Description page of Project Settings.

#include "BTT_Fight.h"
#include "StudentPerceptor.h"
#include "AIController.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "Common/InventoryComponent.h"
#include "Items/Weapon.h"
#include "Zombies/BaseZombie.h"
#include "Survivor/SurvivorPawn.h"
#include "Navigation/PathFollowingComponent.h"

UBTT_Fight::UBTT_Fight()
{
	NodeName    = TEXT("Fight");
	bNotifyTick = true;
}

EBTNodeResult::Type UBTT_Fight::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* Controller = OwnerComp.GetAIOwner();
	if (!Controller) return EBTNodeResult::Failed;

	APawn* Pawn = Controller->GetPawn();
	if (!Pawn)       return EBTNodeResult::Failed;

	UStudentPerceptor* Perceptor = Pawn->GetComponentByClass<UStudentPerceptor>();
	if (!Perceptor)  return EBTNodeResult::Failed;

	if (Perceptor->GetSeenZombies().IsEmpty()) return EBTNodeResult::Failed;

	// No weapon → always flee, fighting is pointless
	ASurvivorPawn* Survivor = Cast<ASurvivorPawn>(Pawn);
	UInventoryComponent* Inv = Survivor ? Survivor->GetComponentByClass<UInventoryComponent>() : nullptr;
	if (!Inv) return EBTNodeResult::Failed;

	const bool bHasWeapon = Inv->GetInventory().ContainsByPredicate(
		[](const ABaseItem* Item){ return IsValid(Item) && Item->IsA<AWeapon>(); });

	if (!bHasWeapon) return EBTNodeResult::Failed;

	FFightMemory* Mem = reinterpret_cast<FFightMemory*>(NodeMemory);
	Mem->TimeSinceSteering = SteeringInterval; // fire immediately

	// Seed speed tracking entries
	Mem->SpeedEntries.Reset();
	for (ABaseZombie* Z : Perceptor->GetSeenZombies())
	{
		if (IsValid(Z))
		{
			FZombieSpeedEntry Entry;
			Entry.Zombie        = Z;
			Entry.LastPosition  = Z->GetActorLocation();
			Entry.SmoothedSpeed = 0.f;
			Mem->SpeedEntries.Add(Entry);
		}
	}

	return EBTNodeResult::InProgress;
}

void UBTT_Fight::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickTask(OwnerComp, NodeMemory, DeltaSeconds);

	AAIController* Controller = OwnerComp.GetAIOwner();
	if (!Controller) { FinishLatentTask(OwnerComp, EBTNodeResult::Failed); return; }

	APawn* Pawn = Controller->GetPawn();
	if (!Pawn)       { FinishLatentTask(OwnerComp, EBTNodeResult::Failed); return; }

	UStudentPerceptor* Perceptor = Pawn->GetComponentByClass<UStudentPerceptor>();
	if (!Perceptor)  { FinishLatentTask(OwnerComp, EBTNodeResult::Failed); return; }

	TArray<ABaseZombie*>& Zombies = Perceptor->GetSeenZombies();

	// No zombies left — fought them off
	if (Zombies.IsEmpty())
	{
		Controller->StopMovement();
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
		return;
	}

	FFightMemory* Mem = reinterpret_cast<FFightMemory*>(NodeMemory);
	Mem->TimeSinceSteering += DeltaSeconds;

	if (Mem->TimeSinceSteering < SteeringInterval) return;
	Mem->TimeSinceSteering = 0.f;

	// ---- Update smoothed speed estimates ----
	// Add entries for any newly-appeared zombies
	for (ABaseZombie* Z : Zombies)
	{
		if (!IsValid(Z)) continue;
		bool bFound = false;
		for (FZombieSpeedEntry& E : Mem->SpeedEntries)
		{
			if (E.Zombie == Z) { bFound = true; break; }
		}
		if (!bFound)
		{
			FZombieSpeedEntry Entry;
			Entry.Zombie        = Z;
			Entry.LastPosition  = Z->GetActorLocation();
			Entry.SmoothedSpeed = 0.f;
			Mem->SpeedEntries.Add(Entry);
		}
	}

	int32 FastCount  = 0;
	int32 AliveCount = 0;

	for (FZombieSpeedEntry& Entry : Mem->SpeedEntries)
	{
		if (!Entry.Zombie.IsValid()) continue;

		const FVector CurPos  = Entry.Zombie->GetActorLocation();
		const float   RawSpeed = FVector::Dist(CurPos, Entry.LastPosition) / SteeringInterval;

		// Exponential moving average
		Entry.SmoothedSpeed = SpeedSmoothingAlpha * Entry.SmoothedSpeed
		                    + (1.f - SpeedSmoothingAlpha) * RawSpeed;
		Entry.LastPosition  = CurPos;

		++AliveCount;
		if (Entry.SmoothedSpeed > FastZombieSpeedThreshold) ++FastCount;
	}

	// ---- Bail only if there are too many slow zombies ----
	// Fast zombies are always fought — the survivor cannot outrun them,
	// so fleeing is futile. Only fall back to Flee when the slow zombie
	// count alone exceeds the threshold.
	const int32 SlowCount = AliveCount - FastCount;
	if (SlowCount > MaxZombiesToFight)
	{
		Controller->StopMovement();
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed); // BT falls to Flee
		return;
	}

	const FVector PawnPos = Pawn->GetActorLocation();

	// ---- Find nearest valid zombie ----
	ABaseZombie* Nearest     = nullptr;
	float        NearestDist = MAX_FLT;

	for (ABaseZombie* Z : Zombies)
	{
		if (!IsValid(Z)) continue;
		const float D = FVector::Dist(PawnPos, Z->GetActorLocation());
		if (D < NearestDist) { NearestDist = D; Nearest = Z; }
	}

	if (!Nearest) return;

	// ---- Attack if in range ----
	if (NearestDist <= AttackRange)
	{
		ASurvivorPawn* Survivor = Cast<ASurvivorPawn>(Pawn);
		if (Survivor)
		{
			UInventoryComponent* Inv = Survivor->GetComponentByClass<UInventoryComponent>();
			if (Inv)
			{
				const TArray<ABaseItem*>& Items = Inv->GetInventory();
				for (int32 i = 0; i < Items.Num(); ++i)
				{
					if (Items[i] && Items[i]->IsA<AWeapon>())
					{
						Inv->UseItem(i);
						break;
					}
				}
			}
		}
	}
	else
	{
		// Move toward nearest zombie
		FAIMoveRequest MoveReq(Nearest->GetActorLocation());
		MoveReq.SetAcceptanceRadius(MoveAcceptanceRadius);
		MoveReq.SetUsePathfinding(true);
		Controller->MoveTo(MoveReq);
	}
}

EBTNodeResult::Type UBTT_Fight::AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	if (AAIController* Controller = OwnerComp.GetAIOwner())
		Controller->StopMovement();
	return Super::AbortTask(OwnerComp, NodeMemory);
}

uint16 UBTT_Fight::GetInstanceMemorySize() const { return sizeof(FFightMemory); }