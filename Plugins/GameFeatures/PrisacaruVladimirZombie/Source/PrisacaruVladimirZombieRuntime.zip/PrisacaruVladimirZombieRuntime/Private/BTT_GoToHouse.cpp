// Fill out your copyright notice in the Description page of Project Settings.

#include "BTT_GoToHouse.h"
#include "StudentPerceptor.h"
#include "AIController.h"
#include "Navigation/PathFollowingComponent.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Village/House/House.h"

UBTT_GoToHouse::UBTT_GoToHouse()
{
	NodeName    = TEXT("Go To House");
	bNotifyTick = true;
}

EBTNodeResult::Type UBTT_GoToHouse::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* Controller = OwnerComp.GetAIOwner();
	if (!Controller) return EBTNodeResult::Failed;

	APawn* Pawn = Controller->GetPawn();
	if (!Pawn)       return EBTNodeResult::Failed;

	UStudentPerceptor* Perceptor = Pawn->GetComponentByClass<UStudentPerceptor>();
	if (!Perceptor)  return EBTNodeResult::Failed;

	const FVector PawnPos = Pawn->GetActorLocation();

	// Find nearest unsearched house
	AHouse* NearestHouse    = nullptr;
	float   NearestDistSq   = MAX_FLT;

	for (AHouse* House : Perceptor->GetSeenHouses())
	{
		if (!IsValid(House) || SearchedHouses.Contains(House)) continue;

		const float D = FVector::DistSquared(PawnPos, House->GetActorLocation());
		if (D < NearestDistSq)
		{
			NearestDistSq = D;
			NearestHouse  = House;
		}
	}

	if (!NearestHouse)
	{
		// All known houses have been searched — reset so we cycle through them
		// again (new items may have spawned since the last visit).
		SearchedHouses.Reset();
		return EBTNodeResult::Failed;
	}

	// Write to blackboard
	if (UBlackboardComponent* BB = Perceptor->GetBlackboard())
		BB->SetValueAsObject(BBKeys::TargetHouse, NearestHouse);

	FGoToHouseMemory* Mem = reinterpret_cast<FGoToHouseMemory*>(NodeMemory);
	Mem->TargetHouse  = NearestHouse;
	Mem->TimeElapsed  = 0.f;

	// Use GetBounds().Origin for the geometric center of the house mesh,
	// not GetActorLocation() which is the actor pivot and may be off-center.
	const FVector HouseCenter = NearestHouse->GetBounds().Origin;

	FAIMoveRequest MoveReq(HouseCenter);
	MoveReq.SetUsePathfinding(true);
	MoveReq.SetAcceptanceRadius(ArrivalRadius);
	Controller->MoveTo(MoveReq);

	return EBTNodeResult::InProgress;
}

void UBTT_GoToHouse::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickTask(OwnerComp, NodeMemory, DeltaSeconds);

	AAIController* Controller = OwnerComp.GetAIOwner();
	if (!Controller) { FinishLatentTask(OwnerComp, EBTNodeResult::Failed); return; }

	APawn* Pawn = Controller->GetPawn();
	if (!Pawn)       { FinishLatentTask(OwnerComp, EBTNodeResult::Failed); return; }

	FGoToHouseMemory* Mem = reinterpret_cast<FGoToHouseMemory*>(NodeMemory);

	if (!Mem->TargetHouse.IsValid())
	{
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
		return;
	}

	// ---- Timeout ----
	Mem->TimeElapsed += DeltaSeconds;
	if (MoveTimeout > 0.f && Mem->TimeElapsed >= MoveTimeout)
	{
		// Mark it searched anyway so we don't loop on the same unreachable house
		SearchedHouses.Add(Mem->TargetHouse.Get());
		Controller->StopMovement();
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
		return;
	}

	// ---- Arrival ----
	// Use 2D distance so the Z offset of GetBounds().Origin (which sits at
	// the mesh's vertical midpoint) doesn't prevent arrival detection when
	// the agent is already standing on the ground at the house.
	// Also treat it as arrived if the path-follower has already finished
	// the move (AlreadyAtGoal or RequestSuccessful).
	const FVector HouseCenter = Mem->TargetHouse->GetBounds().Origin;
	const float Dist2D = FVector::Dist2D(Pawn->GetActorLocation(), HouseCenter);

	const UPathFollowingComponent* PFC = Controller->GetPathFollowingComponent();
	const bool bPathDone = PFC && (PFC->GetStatus() == EPathFollowingStatus::Idle);

	if (Dist2D <= ArrivalRadius || bPathDone)
	{
		SearchedHouses.Add(Mem->TargetHouse.Get());
		Controller->StopMovement();
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
	}
}

EBTNodeResult::Type UBTT_GoToHouse::AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	if (AAIController* Controller = OwnerComp.GetAIOwner())
		Controller->StopMovement();
	return Super::AbortTask(OwnerComp, NodeMemory);
}

uint16 UBTT_GoToHouse::GetInstanceMemorySize() const { return sizeof(FGoToHouseMemory); }