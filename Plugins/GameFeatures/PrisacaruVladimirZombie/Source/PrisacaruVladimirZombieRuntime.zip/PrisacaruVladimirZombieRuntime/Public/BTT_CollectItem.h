// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "Items/BaseItem.h"
#include "Items/ItemType.h"
#include "BTT_CollectItem.generated.h"

/**
 * BTT_CollectItem
 *
 * Finds the best item from the perceptor's SeenItems list and walks to it.
 *
 * Priority:
 *   - If HP < LowHealthThreshold (fraction 0–1): prefer Medkit, then Food.
 *   - If HP >= threshold: prefer weapons (Shotgun > Pistol), then Food.
 *   - If the best item is farther than the nearest unsearched house, fails
 *     so the BT can fall through to BTT_GoToHouse instead.
 *
 * On arrival (within InventoryComponent::PickupRange), calls GrabItem.
 * Writes the chosen item to BB key "TargetItem" so decorators can read it.
 */
UCLASS()
class PRISACARUVLADIMIRZOMBIERUNTIME_API UBTT_CollectItem : public UBTTaskNode
{
	GENERATED_BODY()

public:
	UBTT_CollectItem();

	/** Health fraction below which healing items are prioritised (0–1). */
	UPROPERTY(EditAnywhere, Category="CollectItem", meta=(ClampMin="0.0", ClampMax="1.0"))
	float LowHealthThreshold = 0.3f;

	/** Timeout before giving up on a single move (0 = never). */
	UPROPERTY(EditAnywhere, Category="CollectItem", meta=(ClampMin="0.0"))
	float MoveTimeout = 15.f;

protected:
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp,
											uint8* NodeMemory) override;
	virtual void TickTask(UBehaviorTreeComponent& OwnerComp,
						  uint8* NodeMemory,
						  float DeltaSeconds) override;
	virtual EBTNodeResult::Type AbortTask(UBehaviorTreeComponent& OwnerComp,
										  uint8* NodeMemory) override;
	virtual uint16 GetInstanceMemorySize() const override;

private:
	ABaseItem* PickBestItem(APawn* Pawn) const;
};

struct FCollectItemMemory
{
	TWeakObjectPtr<ABaseItem> TargetItem;
	float TimeElapsed { 0.f };
};