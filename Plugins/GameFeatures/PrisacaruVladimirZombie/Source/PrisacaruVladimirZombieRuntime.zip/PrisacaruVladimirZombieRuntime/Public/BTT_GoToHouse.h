// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "Village/House/House.h"
#include "BTT_GoToHouse.generated.h"

/**
 * BTT_GoToHouse
 *
 * Moves to the center of the nearest unsearched house from the perceptor's
 * SeenHouses list.  On arrival, does NOT spin itself — it finishes Succeeded
 * so the BT can chain into BTT_Spin360 to scan for items.
 *
 * A house is marked "searched" by adding it to the SearchedHouses set inside
 * this task on arrival.  On subsequent runs the task skips already-searched
 * houses, ensuring the agent cycles through all known houses.
 *
 * Writes the chosen house to BB key "TargetHouse".
 *
 * If no unsearched houses are known, fails so the BT can fall back to
 * SmartWander to find new ones.
 */
UCLASS()
class PRISACARUVLADIMIRZOMBIERUNTIME_API UBTT_GoToHouse : public UBTTaskNode
{
	GENERATED_BODY()

public:
	UBTT_GoToHouse();

	/** Acceptance radius to consider the agent "at" the house center. */
	UPROPERTY(EditAnywhere, Category="GoToHouse", meta=(ClampMin="10.0"))
	float ArrivalRadius = 200.f;

	/** Timeout before giving up on a move (0 = never). */
	UPROPERTY(EditAnywhere, Category="GoToHouse", meta=(ClampMin="0.0"))
	float MoveTimeout = 20.f;

protected:
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp,
	                                        uint8* NodeMemory) override;
	virtual void TickTask(UBehaviorTreeComponent& OwnerComp,
	                      uint8* NodeMemory,
	                      float DeltaSeconds) override;
	virtual EBTNodeResult::Type AbortTask(UBehaviorTreeComponent& OwnerComp,
	                                      uint8* NodeMemory) override;
	virtual uint16 GetInstanceMemorySize() const override;

private:
	// Persists across activations so the agent keeps moving to new houses
	UPROPERTY()
	TSet<AHouse*> SearchedHouses;
};

struct FGoToHouseMemory
{
	TWeakObjectPtr<AHouse> TargetHouse;
	float TimeElapsed { 0.f };
};