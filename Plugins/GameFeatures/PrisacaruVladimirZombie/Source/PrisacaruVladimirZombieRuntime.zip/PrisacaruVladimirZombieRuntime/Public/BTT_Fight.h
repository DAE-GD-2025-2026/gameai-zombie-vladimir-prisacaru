// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "BTT_Fight.generated.h"

/**
 * BTT_Fight
 *
 * Engages zombies when there are few of them and none are "fast".
 *
 * Fast-zombie estimation: tracks each zombie's position from the previous
 * steering update and computes a smoothed speed estimate. Zombies whose
 * smoothed speed exceeds FastZombieSpeedThreshold are counted as fast.
 *
 * Decision each SteeringInterval:
 *   - If ZombieCount > MaxZombiesToFight OR FastZombieCount > 0 → Fail
 *     (BT should fall through to Flee).
 *   - Otherwise: move toward the nearest zombie. If within AttackRange,
 *     use the first weapon in the inventory against it.
 *
 * When all tracked zombies are cleared (by BTT_Flee's culling logic or
 * because they died), finishes Succeeded.
 */
UCLASS()
class PRISACARUVLADIMIRZOMBIERUNTIME_API UBTT_Fight : public UBTTaskNode
{
	GENERATED_BODY()

public:
	UBTT_Fight();

	/** Fight only if the count of SLOW zombies is at most this many.
	 *  Fast zombies are always fought regardless of this limit. */
	UPROPERTY(EditAnywhere, Category="Fight", meta=(ClampMin="1"))
	int32 MaxZombiesToFight = 2;

	/** Smoothed speed above which a zombie is considered "fast" (UU/s). */
	UPROPERTY(EditAnywhere, Category="Fight", meta=(ClampMin="1.0"))
	float FastZombieSpeedThreshold = 350.f;

	/** Smoothing factor for speed estimation (0=no smoothing, 1=never updates). */
	UPROPERTY(EditAnywhere, Category="Fight", meta=(ClampMin="0.0", ClampMax="0.99"))
	float SpeedSmoothingAlpha = 0.7f;

	/** Distance at which the survivor tries to use their weapon. */
	UPROPERTY(EditAnywhere, Category="Fight", meta=(ClampMin="10.0"))
	float AttackRange = 200.f;

	/** How often steering and combat checks run. */
	UPROPERTY(EditAnywhere, Category="Fight", meta=(ClampMin="0.01"))
	float SteeringInterval = 0.15f;

	/** MoveTo acceptance radius when closing in on a zombie. */
	UPROPERTY(EditAnywhere, Category="Fight", meta=(ClampMin="10.0"))
	float MoveAcceptanceRadius = 80.f;

protected:
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp,
	                                        uint8* NodeMemory) override;
	virtual void TickTask(UBehaviorTreeComponent& OwnerComp,
	                      uint8* NodeMemory,
	                      float DeltaSeconds) override;
	virtual EBTNodeResult::Type AbortTask(UBehaviorTreeComponent& OwnerComp,
	                                      uint8* NodeMemory) override;
	virtual uint16 GetInstanceMemorySize() const override;
};

// Per-zombie speed tracking entry
struct FZombieSpeedEntry
{
	TWeakObjectPtr<class ABaseZombie> Zombie;
	FVector  LastPosition     { FVector::ZeroVector };
	float    SmoothedSpeed    { 0.f };
};

struct FFightMemory
{
	float                    TimeSinceSteering { 0.f };
	TArray<FZombieSpeedEntry> SpeedEntries;
};