﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AISenseConfig_Damage.h"
#include "Perception/AISense_Damage.h"
#include "Items/BaseItem.h"
#include "Village/House/House.h"
#include "Zombies/BaseZombie.h"
#include "PurgeZones/PurgeZone.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "StudentPerceptor.generated.h"

// ---- Blackboard key names (single source of truth) ----
// Use these constants everywhere instead of raw string literals.
namespace BBKeys
{
	static const FName SeesZombies        { TEXT("bSeesZombies")        };
	static const FName SeesPurgeZone      { TEXT("bSeesPurgeZone")      };
	static const FName FleeFromLocation   { TEXT("FleeFromLocation")    };
	static const FName ShouldSpin         { TEXT("bShouldSpin")         };
	static const FName TargetItem         { TEXT("TargetItem")          };
	static const FName TargetHouse        { TEXT("TargetHouse")         };
	// True whenever SeenItems or SeenHouses is non-empty — used to abort SmartWander
	static const FName HasActionableItem  { TEXT("bHasActionableItem")  };
}

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class PRISACARUVLADIMIRZOMBIERUNTIME_API UStudentPerceptor : public UActorComponent
{
	GENERATED_BODY()

public:
	UStudentPerceptor();

	virtual void BeginPlay() override;

	UFUNCTION()
	virtual void OnPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus);

	// -------------------------------------------------------
	// Exploration data – used by BTT_SmartWander
	// -------------------------------------------------------

	UFUNCTION(BlueprintCallable, BlueprintPure, Category="Exploration")
	const TArray<FVector>& GetExploredPositions() const { return ExploredPositions; }

	UFUNCTION(BlueprintCallable, Category="Exploration")
	void MarkCurrentPositionExplored();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category="Exploration")
	int32 GetExplorationDensity(const FVector& WorldPos, float Radius) const;

	// -------------------------------------------------------
	// Perceived actor caches
	// -------------------------------------------------------

	UFUNCTION(BlueprintCallable, Category="Cache")
	TArray<ABaseItem*>& GetSeenItems() { return SeenItems; }

	UFUNCTION(BlueprintCallable, Category="Cache")
	TArray<AHouse*>& GetSeenHouses() { return SeenHouses; }

	UFUNCTION(BlueprintCallable, Category="Cache")
	TArray<ABaseZombie*>& GetSeenZombies() { return SeenZombies; }

	UFUNCTION(BlueprintCallable, Category="Cache")
	TArray<APurgeZone*>& GetSeenPurgeZones() { return SeenPurgeZones; }

	// -------------------------------------------------------
	// Blackboard helpers – called by tasks and internally
	// -------------------------------------------------------

	/** Re-evaluates bSeesZombies and FleeFromLocation from SeenZombies. */
	void UpdateBlackboardZombieFlag();

	/** Re-evaluates bSeesPurgeZone and FleeFromLocation from SeenPurgeZones. */
	void UpdateBlackboardPurgeFlag();

	/** Re-evaluates bHasActionableItem from SeenItems + SeenHouses.
	 *  Call whenever either list changes so SmartWander can be interrupted. */
	void UpdateBlackboardActionableFlag();

	UBlackboardComponent* GetBlackboard() const { return BB; }

private:
	UPROPERTY()
	UBlackboardComponent* BB { nullptr };

	UPROPERTY()
	TArray<FVector> ExploredPositions;

	static constexpr float MinRecordDistance = 150.f;

	UPROPERTY()
	TArray<ABaseItem*> SeenItems;

	UPROPERTY()
	TArray<AHouse*> SeenHouses;

	UPROPERTY()
	TArray<ABaseZombie*> SeenZombies;

	UPROPERTY()
	TArray<APurgeZone*> SeenPurgeZones;
};